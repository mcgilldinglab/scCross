Codes for scCross.
